# Fleet Stable v1

Frozen portable Shadow Candidate. Six physical coordinates, psi (basis unverified). Local absolute median/MAD-IQR scales are frozen; Fleet shares compatible correlation shape only. JSON/scalers/covariance/target thresholds are checksum verified. No live fitting, adaptation, PLC write or alert vote.

Install with apps.api.app.fleet_bundle; select a Shadow pointer with expected revision. New training produces a new immutable version. Production needs reviewed healthy references, verified contracts, independent/future validation and target-server lifecycle acceptance.
